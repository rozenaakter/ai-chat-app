(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_socket_io-client_build_esm_index_ca528017.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_micromark-core-commonmark_dev_lib_fc41dd51._.js",
  "static/chunks/node_modules_b3218f0b._.js",
  "static/chunks/_25a052da._.js"
],
    source: "dynamic"
});
