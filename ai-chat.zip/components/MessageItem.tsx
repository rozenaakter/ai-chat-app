'use client'

import { useEffect, useRef } from 'react'
import { Bot, User } from 'lucide-react'
import ReactMarkdown from 'react-markdown'

interface MessageItemProps {
    message: Message
    socket: any
    currentUsername: string
    isLoading?: boolean
}

interface Message {
    id: string
    content: string
    username: string
    createdAt: string
    isAi?: boolean
    readBy: string[]
}

export function MessageItem({ message, socket, currentUsername, isLoading }: MessageItemProps) {
    const messageRef = useRef<HTMLDivElement>(null);


    useEffect(() => {
        if (messageRef.current && socket) {
            const observer = new IntersectionObserver(
                ([entry]) => {
                    if (entry.isIntersecting) {
                        if (!message.readBy.includes(currentUsername)) {
                            socket.emit('message-read', { messageId: message.id, username: currentUsername })
                        }
                        observer.disconnect()
                    }
                },
                { threshold: 1.0 }
            )
            observer.observe(messageRef.current)
            return () => observer.disconnect()
        }
    }, [message, socket, currentUsername])

    const getReadByTooltip = () => {
        const readers = message.readBy.filter(u => u !== message.username && u !== currentUsername)
        if (readers.length === 0) return ''
        if (readers.length > 3) {
            return `Read by ${readers.slice(0, 3).join(', ')} and ${readers.length - 3} others`
        }
        return `Read by ${readers.join(', ')}`
    }

    if (isLoading) {
        return (
            <div className="flex gap-3 items-start">
                <div className="flex-shrink-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <Bot className="h-4 w-4 text-primary-foreground" />
                </div>
                <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-sm">AI</span>
                    </div>
                    <div className="bg-muted rounded-lg p-3">
                        <p className="text-sm">AI is thinking...</p>
                    </div>
                </div>
            </div>
        )
    }


    return <div ref={messageRef} className={`flex gap-3 ${message.isAi ? 'items-start' : ''}`}>
        {message.isAi && (
            <div className="flex-shrink-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <Bot className="h-4 w-4 text-primary-foreground" />
            </div>
        )}
        <div className={`flex-1 ${message.isAi ? '' : 'ml-11'}`}>
            <div className="flex items-center gap-2 mb-1">
                <span className="font-semibold text-sm">{message.username}</span>
                <span className="text-xs text-muted-foreground">
                    {new Date(message.createdAt).toLocaleTimeString()}
                </span>
            </div>
        </div>

        <div className="bg-muted rounded-lg p-3">
            {message.isAi && message.content ? (
                <ReactMarkdown>
                    {message.content}
                </ReactMarkdown>
            ): (
                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
            )}
            {message.readBy && message.readBy.length > 1 && message.username === currentUsername && (
                <div className="text-xs text-muted-foreground mt-1" title={getReadByTooltip()}>
                    Read by {message.readBy.filter(u => u !== message.username).length}
                </div>
            )}
        </div>

    </div>;
}